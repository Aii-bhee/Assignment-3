from setuptools import setup, find_packages

setup(
    name='SimpleGame',
    version='2.6.7',
    description='A simple wrapper for pgzero to make it more accessible for Beginners.',
    author='Setareh Aghel Manesh',
    package_data={},
    packages=find_packages(),
    install_requires=[
        'pgzero',
        'pygame',
    ]
)
