from tkinter import Tk
import os

HEIGHT = 750
WIDTH = 750
_WINDOW_X = round((Tk().winfo_screenwidth() - WIDTH) / 2)
_WINDOW_Y = 30
os.environ['SDL_VIDEO_WINDOW_POS'] = f'{_WINDOW_X},{_WINDOW_Y}'

import pgzrun
from pgzero.builtins import Actor, clock, music
from pgzrun import mod
from pygame import mixer
_POSITION_TYPES = {'left', 'right', 'bottom', 'top', 'center'}


def create_element(imageName: str, centerPos: tuple = (0, 0)) -> dict:
    """
    Creates a game element from the images folder at the given position. \
    Must be of type **.png**

    .. important:: Do not include the file extension

    :param imageName: Name of the image file to use for the element.
    :type imageName: str
    :param centerPos: The center position of the element on the screen, defaults to (0, 0).
    :type centerPos: tuple
    :return: A dictionary representing the game element, with an 'id' key pointing to an Actor instance.
    :rtype: dict

    
    .. admonition:: Example

       To create an element with an image inside the images folder called: star.png\n
       starElement = create_element('star')

    """
    try:
        element = {
            'id': Actor(imageName, pos=centerPos, anchor=('center', 'center'))
        }

        return element
    except Exception as e:
        raise Exception(f"Failed to create element: {e}")


def move_to_position(element: dict, newPosition: tuple):
    """
    Moves the element to the specified new position.

    :param element: The game element to move.
    :type element: dict
    :param newPosition: The (x, y) position to move the element to.
    :type newPosition: tuple
    :return: None

    .. admonition:: Example

       To move the star to the following coordinates: x=200, y=300\n
       move_to_position(starElement, (200,300))
    """
    try:
        element['id'].pos = newPosition
    except Exception as e:
        raise Exception(f"Failed to move element: {e}")


def rotate_by(element: dict, degrees: int):
    """
    Rotates an element clockwise by the number of degrees given. \
        Remember that angles loop round, so 0 degrees == 360 degrees == 720 degrees. Likewise -180 degrees == 180 degrees.

    :param element: The game element to move.
    :type element: dict
    :param degrees: Rotation degrees in clock wise. You may use negative numbers for counterclockwise. 
    :type offset: int
    :return: None

    .. admonition:: Example

       To rotate star by 90 degrees to the right\n
       rotate_cw_by(starElement, 90)\n
       or\n
       rotate_cw_by(starElement, -270)\n
    """
    element['id'].angle -= degrees

def get_rotation_angle(element: dict):
    """
    Returns the rotation of the element, in degrees, clockwise from the original orientation. \
        Remember that angles loop round, so 0 degrees == 360 degrees == 720 degrees. Likewise -180 degrees == 180 degrees.

    :param element: The game element to move.
    :type element: dict
    :return: rotation of the element, in degrees, clockwise from the original orientation (0-360)
    :rtype: int

    .. admonition:: Example

       To know by how many degrees star has been rotated by\n
       rotate_cw_by(starElement, 90)
    """
    return -element['id'].angle%360


def move_by_offset(element: dict, offset: tuple):
    """
    Moves an element by adding specified amounts to its current position.

    :param element: The game element to move.
    :type element: dict
    :param offset: Moves the element by the given offset. 
    :type offset: tuple
    :return: None

    Offsets affects movement as follows:\n
    - If x or y are zero, the element does not move on that axis.\n
    - Negative x: move left.\n
    - Positive x: move right.\n
    - Negative y: move up.\n
    - Positive y: move down.\n

    .. admonition:: Example

       To move the star 1 pixel to the right\n
       move_by_offset(starElement, (1, 0))
    """
    try:
        element['id'].x += offset[0]
        element['id'].y += offset[1]
    except Exception as e:
        raise Exception(f"Failed to move element by offset: {e}")


def get_position(element, position_type):
    """
    Returns the specified position of an element based on the position_type argument.

    :param element: The game element to get the position for.
    :type element: dict
    :param position_type: Specifies the edge or center of the element to get \
    the position of. Must be one of 'left', 'right', 'bottom', 'top', 'center'.
    :type position_type: str
    :return: The coordinate of the specified edge or the center position of \
    the element. Returns a float for 'left', 'right', 'bottom', 'top' and a tuple for 'center'.
    :rtype: float or tuple

    The function calculates and returns the position based on the `position_type`:

    - 'left': returns the x-coordinate of the left edge of the element.
    - 'right': returns the x-coordinate of the right edge of the element.
    - 'bottom': returns the y-coordinate of the bottom edge of the element.
    - 'top': returns the y-coordinate of the top edge of the element.
    - 'center': returns a tuple (x, y) representing the center position of the element.

    .. admonition:: Example
    
       To find the value for the left of the image of the star on screen:\n
       starLeft = get_position(starElement, 'left')
    """
    actor = element['id']

    if position_type == 'left':
        return actor.left
    elif position_type == 'right':
        return actor.right
    elif position_type == 'bottom':
        return actor.bottom
    elif position_type == 'top':
        return actor.top
    elif position_type == 'center':
        return actor.pos  # Actor's pos attribute already returns the center (x, y) as a tuple
    else:
        raise ValueError("Invalid position type specified.")


def change_image(element: dict, newImage: str):
    """
    Changes the image of an element.

    :param element: The game element to modify.
    :type element: dict
    :param newImage: The name of the new image file for the element.
    :type newImage: str
    :return: None

    .. admonition:: Example
    
       To change the image for the star element to star2.png\n
       change_image(starElement, 'star2')
    """
    try:
        element['id'].image = newImage
        element['id'].angle += 0
    except Exception as e:
        raise Exception(f"Failed to change element image to {newImage}: {e}")


def get_image(element: dict) -> str:
    """
    Retrieves the current image of an element.

    :param element: The game element to inspect.
    :type element: dict
    :return: The name of the current image file of the element.
    :rtype: str

    .. admonition:: Example
    
       To find the image currently set for the starElement\n
       get_image(starElement)
    """
    try:
        return element['id'].image
    except Exception as e:
        raise Exception(f"Failed to get element image: {e}")


def get_key_pressed(key) -> str:
    """
    Determines if a specified key is pressed.

    :param key: The key code to check.
    :type key: const
    :return: The name of the key, in lowercase, if pressed. Returns an empty string if the key is not recognized.
    :rtype: str

    .. admonition:: Example
    
       To get the string representation of the key pressed inside on_key_down(key)\n
       key_pressed = get_key_pressed(key)
    """
    try:
        return key.name.lower()
    except AttributeError as e:
        raise AttributeError(f"Failed to get the key: {e}")


def schedule_callback_after(callback, seconds: float):
    """
    .. important :: When passing a function as an argument, DO NOT included () & make sure it doesn't have any parameters.

    Schedules a callback to be called after a delay.

    :param callback: The function to call after the delay.
    :type callback: function
    :param seconds: The delay, in seconds, after which to call the callback.
    :type seconds: float
    :return: None

    .. admonition:: Example
    
       To call a function called foo() after 500 milliseconds \n
       schedule_callback_after(foo, 0.5)
    """
    try:
        clock.schedule(callback, seconds)
    except Exception as e:
        raise Exception(f"Failed to schedule callback after delay: {e}")


def schedule_callback_every(callback, seconds: float):
    """
    .. important :: When passing a function as an argument, DO NOT included () & make sure it doesn't have any parameters.

    Schedules a callback to be called at fixed intervals.

    :param callback: The function to call repeatedly.
    :type callback: function
    :param seconds: The interval, in seconds, at which to call the callback.
    :type seconds: float
    :return: None

    .. admonition:: Example
    
       To call a function called foo() every 2100 milliseconds \n
       schedule_callback_every(foo, 2.1)
    """
    try:
        clock.schedule_interval(callback, seconds)
    except Exception as e:
        raise Exception(f"Failed to schedule repeated callback: {e}")


def cancel_callback_schedule(callback):
    """
    Cancels a previously scheduled callback.

    :param callback: The callback function to cancel.
    :type callback: function
    :return: None

    .. admonition:: Example
    
       To cancel a previously scheduled function call for foo() \n
       cancel_callback_schedule(foo)
    """
    try:
        clock.unschedule(callback)
    except Exception as e:
        raise Exception(f"Failed to cancel callback: {e}")


def draw_background(bgImage=None, bgColor=None):
    """
    .. important:: This function should only be called inside the draw() function.

    Draws the background of the screen using either an image or a solid color.

    :param bgImage: The name of the image file to use as the new background. If specified, the image is drawn as the background. If `None`, `bgColor` is considered.
    :type bgImage: str, optional
    :param bgColor: The color to use as the background if no image is specified.
    :type bgColor: str, optional
    :return: None

    If neither bgImage nor bgColor is specified, the background will be cleared.

    .. admonition:: Example
    
       Inside the draw() function: \n
        - make the background red : draw_background(bgColor='red')
        - use the 'background1.png' in the images folder as background: draw_background(bgImage='background1')
    """
    try:
        if bgImage:
            mod.screen.blit(bgImage, (0, 0))
        elif bgColor:
            mod.screen.fill(bgColor)
        else:
            mod.screen.clear()
    except Exception as e:
        raise Exception(f"Failed to draw background image: {e}")


def draw_element(element: dict):
    """
    .. important:: This function should only be called inside the draw() function.

    Draws the specified game element on the screen.

    :param element: The game element to draw.
    :type element: dict
    :return: None

    .. admonition:: Example
    
       Inside the draw() function to show an already created element. \n
       draw_element(starElement)
    """
    try:
        element['id'].draw()
    except Exception as e:
        raise Exception(f"Failed to draw element: {e}")


def draw_text_on_screen(text: str, centerPosition: tuple, **kwargs):
    """
    .. important:: This function should only be called inside the draw() function.

    Places text on the screen at a specified center position, with detailed customization options.

    :param text: The text to display on the screen.
    :type text: str
    :param centerPosition: The center position (x, y) for the text.
    :type centerPosition: tuple
    :return: None

    Additional keyword arguments can be passed to customize the text appearance. These include:\n
    - fontsize (int): Specifies the size of the text. Default is 24.
    - color (str or tuple): Defines the color of the text. Can be a string (e.g., 'white') or an RGB tuple (255, 255, 255). Default is 'white'.
    - backgroundColor (str or tuple, optional): Sets the background color of the text. Similar format to 'color'. Default is None (transparent).
    - bold (bool): If True, renders the text in bold. Default is False.
    - italic (bool): If True, renders the text in italic. Default is False.
    - underline (bool): If True, underlines the text. Default is False.
    - alpha (float): Controls the opacity of the text, where 1.0 is fully opaque and 0.0 is fully transparent. Default is 1.0.
    - align (str): Text alignment, can be 'left', 'center', or 'right'. Default is 'left'.

    .. admonition:: Example
    
       Inside the draw() function to show a red bold text, size 30 saying 'Hello!!' in the middle of the screen . \n
       draw_text_on_screen("Hello!!", (WIDTH/2, HEIGHT/2), fontSize=30, color='red', bold=True)
    """
    try:
        mod.screen.draw.text(text, center=centerPosition, **kwargs)
    except Exception as e:
        raise Exception(f"Failed to draw text on screen: {e}")


def play_sound_clip(sound_name: str):
    """
    Plays a sound clip from the sounds folder once. \
    Must be of type **.wav**

    .. important:: Do not include the file extension

    :param sound_name: name of the sound clip in sounds folder. Must include file extension.
    :type sound_name: str
    :return: None

    .. admonition:: Example
    
       To play a short audio file in the sounds folder called tic.wav \n
       play_sound_clip('tic')
    """
    mixer.Sound.play(mixer.Sound(f'sounds/{sound_name}.wav'))


def manage_background_music(music_name: str, action: str, volume: float = 1, fadeoutDuration: float = 0):
    """
    Updates the music track according to the specific action. If multiple actions are desired, \
    you must call this function multiple times. Must be of type **.wav**

    .. important:: Do not include the file extension

    :param music_name: The name of the music track
    :type music_name: str
    :param action: The action to be performed on music track
    :type action: str
    :param volume: The volume of the background music which is a number between 0 (meaning silent) and 1 (meaning full volume)
    :type volume: float
    :param fadeoutDuration: The duration in seconds over which the sound will be faded out.
    :type fadeoutDuration: float
    :return: None / Returns True if the music is playing (and is not paused), False otherwise.
    :rtype: None / bool

    .. admonition:: Example
    
       To play an audio file in the music folder called upbeat.wav\n
       manage_background_music('upbeat', action='play')
    """

    if '.' in music_name:
        raise ValueError("Do not include the file extensions.")
    music_name += '.wav'

    if action == 'play':
        return music.play(music_name)
    elif action == 'stop':
        return music.stop()
    elif action == 'play-once':
        return music.play_once(music_name)
    elif action == 'change-volume':
        return music.set_volume(volume)
    elif action == 'pause':
        return music.pause()
    elif action == 'resume':
        return music.unpause()
    elif action == 'fadeout':
        return music.fadeout(fadeoutDuration)
    elif action == 'is-playing':
        return music.is_playing()
    else:
        raise ValueError(f'{action} is not a valid action.')


def run_game():
    """
    Starts the Pygame Zero game loop. Without including this function at \
    the end of your game, the screen will not be drawn.

    :return: None
    """
    pgzrun.go()
